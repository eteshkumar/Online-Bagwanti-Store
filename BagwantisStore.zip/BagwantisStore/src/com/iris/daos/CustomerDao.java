package com.iris.daos;

import java.util.List;

import com.iris.models.Customer;

public interface CustomerDao {
public boolean registerCustomer(Customer cust) throws Exception;
public Customer validateUser(String name,String password) throws Exception; 
public List<Customer> ViewCustomers() throws Exception;
public boolean deleteCustomer (int id) throws Exception;
public boolean updateCustomer (Customer c) throws Exception;
public Customer getCustomer(int id) throws Exception;

}
