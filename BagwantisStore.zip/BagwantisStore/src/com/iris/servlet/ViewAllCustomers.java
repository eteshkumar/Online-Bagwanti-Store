package com.iris.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daos.CustomerDao;
import com.iris.daosimpl.CustomerDaoImpl;
import com.iris.models.Customer;

/**
 * Servlet implementation class ViewAllCustomers
 */
@WebServlet("/ViewAllCustomers")
public class ViewAllCustomers extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public ViewAllCustomers() {
        super();
            }

	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		CustomerDao daos = new CustomerDaoImpl();
		try {
			List<Customer> l=new ArrayList<>();	
			l=daos.ViewCustomers();
			out.println("<div align='center'>");
			out.println("<table border='1px'>");
			out.println("<tr>");
			out.println("<th>CustomerId</th>");
			out.println("<th>CustomerName</th>");
			out.println("<th>Gender</th>");
			out.println("<th>EMailAddress</th>");
			out.println("<th>City</th>");
			out.println("<th>Role</th>");
			out.println("</tr>");

			for(Customer c:l) {
			out.println("<tr>");
			out.println("<td>"+c.getCustomerId()+"</td>");
			out.println("<td>"+c.getCustomerName()+"</td>");
			out.println("<td>"+c.getGender()+"</td>");
			out.println("<td>"+c.getEmailaddress()+"</td>");
			out.println("<td>"+c.getCity()+"</td>");
			out.println("<td>"+c.getRole()+"</td>");
			out.println("<td> <a href='UpdateServlate?cuid="+c.getCustomerId()+"'>Update</a></td>");
			out.println("<td> <a href='Delete?cid="+c.getCustomerId()+"'>Delete</a></td>");
			out.println("</tr>");
			
		
		}
			out.println("</table>");
			out.println("</div>");
		}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	}

