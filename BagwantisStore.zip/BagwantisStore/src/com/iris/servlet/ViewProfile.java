package com.iris.servlet;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.iris.models.Customer;

@WebServlet("/ViewProfile")
public class ViewProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ViewProfile() {
        super();
      
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		Customer cust=(Customer)session.getAttribute("custObj");
		out.println("<div align='center'>");
		out.println("<table border='1px solid black'>");
		out.println("<tr>");
		out.println("<th>CustomerId</th>");
		out.println("<th>CustomerName</th>");
		out.println("<th>Gender</th>");
		out.println("<th>EMailAddress</th>");
		out.println("<th>City</th>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>"+cust.getCustomerId()+"</td>");
		out.println("<td>"+cust.getCustomerName()+"</td>");
		out.println("<td>"+cust.getGender()+"</td>");
		out.println("<td>"+cust.getEmailaddress()+"</td>");
		out.println("<td>"+cust.getCity()+"</td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</div>");
		
	}

}
