package com.iris.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daos.CustomerDao;
import com.iris.daosimpl.CustomerDaoImpl;
import com.iris.models.Customer;

@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		CustomerDao cdao=new CustomerDaoImpl();
		String s1=request.getParameter("cid");
		int n=Integer.parseInt(s1);
		String s2=request.getParameter("cname");
		String s3=request.getParameter("cgen");
		String s4=request.getParameter("cemail");
		String s5=request.getParameter("pass");
		String s6=request.getParameter("city");
		
		Customer c=new Customer();
		c.setCustomerId(n);
		c.setCustomerName(s2);
		c.setGender(s3);
		c.setEmailaddress(s4);
		c.setPassword(s5);
		c.setCity(s6);
		
	
		boolean a=false;
		try {
			a=cdao.updateCustomer(c);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		if(a==true) {
			out.println("Updated Successfully!!");
			RequestDispatcher rd=request.getRequestDispatcher("ViewAllCustomers");
			rd.forward(request, response);
		}
		else {
			out.println("Not Updated!!");
		}
	}

}
