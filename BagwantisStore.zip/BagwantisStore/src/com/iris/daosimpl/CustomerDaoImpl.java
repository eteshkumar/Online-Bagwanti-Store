package com.iris.daosimpl;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.iris.daos.CustomerDao;
import com.iris.models.Customer;
import com.iris.utility.ConnectionProvider;

public class CustomerDaoImpl implements CustomerDao {
	Connection Conn=ConnectionProvider.getConn();

	@Override
	public boolean registerCustomer(Customer cust) throws Exception {
		PreparedStatement ps=Conn.prepareStatement("insert into customerstable values(id.nextval,?,?,?,?,?,'customer')");
		ps.setString(1, cust.getCustomerName());
		ps.setString(2, cust.getGender());
		ps.setString(3, cust.getEmailaddress());
		ps.setString(4, cust.getPassword());
		ps.setString(5, cust.getCity());
		int i=ps.executeUpdate();
		if(i!=0) {
			return true;
		}
			
		return false;
		
	}
	public Customer validateUser(String customerName,String password) throws Exception{
		PreparedStatement ps=Conn.prepareStatement("select * from customerstable where Customername=? and Password=?");
		ps.setString(1, customerName);
		ps.setString(2, password);
		ResultSet a=ps.executeQuery();
		if(a.next()) {
			
			int id=a.getInt(1);
			String s1=a.getString(2);
			String s2=a.getString(3);
			String s3=a.getString(4);
			String s4=a.getString(5);
			String s5=a.getString(6);
			String s6=a.getString(7);
			
			  
			
			
			Customer c1=new Customer(id,s1,s2,s3,s4,s5,s6);
			System.out.println(c1);
			return c1;
			
		
		
		}
		else return  null;

		
		
		
	}
	public List<Customer> ViewCustomers()  throws Exception{
		List<Customer> customerList=new ArrayList<>();	
		Statement st=Conn.createStatement();
		ResultSet rs=st.executeQuery("select * from customerstable where Role='customer'");
		while(rs.next()) {

			int cid=rs.getInt(1);
			String cname=rs.getString(2);
			String cgen=rs.getString(3);
			String cemail=rs.getString(4);
			String cpass=rs.getString(5);
			String ccity=rs.getString(6);
			String crole=rs.getString(7);
			Customer c2=new Customer(cid,cname,cgen,cemail,cpass,ccity,crole);
			  customerList.add(c2);
		}
		return customerList;
		
	}
	public boolean deleteCustomer (int id) throws Exception{
		PreparedStatement ps=Conn.prepareStatement("delete from customerstable where CustomerId=? ");
		ps.setInt(1, id);
		int i1=ps.executeUpdate();
		if(i1!=0) {
			return true;
		}
		else return false;
	}
	public Customer getCustomer(int id) throws Exception {
		PreparedStatement ps = Conn.prepareStatement("Select * from Customers where CustomerId=?");
		ps.setInt(1, id);
		ResultSet a = ps.executeQuery();

		if (a.next()) {
			Customer c = new Customer();
			c.setCustomerId(a.getInt(1));

			c.setCustomerName((a.getString(2)));
			c.setGender(a.getString(3));
			c.setEmailaddress(a.getString(4));
			c.setPassword(a.getString(5));
			c.setCity(a.getString(6));

			return c;
		}
		return null;
	}
	public boolean updateCustomer (Customer c) throws Exception{
		PreparedStatement ps=Conn.prepareStatement("update customerstable set customerName=?,gender=?,emailaddress=?,password=?,city=? where CustomerId=?");
		ps.setString(1, c.getCustomerName());
		ps.setString(2, c.getGender());
		ps.setString(3, c.getEmailaddress());
		ps.setString(4, c.getPassword());
		ps.setString(5, c.getCity());
		int i=ps.executeUpdate();
		if(i!=0) {
			return true;
			
		}
		else return false;
		
		}
		
	}
	






